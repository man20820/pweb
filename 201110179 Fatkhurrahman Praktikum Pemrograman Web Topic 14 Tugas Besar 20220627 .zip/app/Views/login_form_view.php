<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
</head>

<body>
    <h2>Admin Login</h2>
    <form action="login" method="post">
        <p>Username</p>
        <input type="text" name="username">
        <p>Password</p>
        <input type="text" name="password">
        <input type="submit" name="btnSubmit" value="Login">
    </form>
</body>

</html>